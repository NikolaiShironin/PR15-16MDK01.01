﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ListClass.Classes;
using System.IO;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // List<Pharmacy> pharmacies = new List<Pharmacy>();
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.ReadListFromFile(@"Input.txt");

            DtgListWorkers.ItemsSource = ConnectHelper.Employer;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.ToList();
            DtgListWorkers.SelectedIndex = -1;
            ConnectHelper.Employer.Max(X => X.PostWorker);
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.OrderBy(x => x.NameWorker).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.OrderByDescending(x => x.NameWorker).ToList();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x => x.NameWorker.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = null;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            WindowAddPreparate windowAdd = new WindowAddPreparate((sender as Button).DataContext as Employees);
            windowAdd.ShowDialog();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var resMessage = MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (resMessage == MessageBoxResult.Yes)
            {
                int ind = DtgListWorkers.SelectedIndex;
                ConnectHelper.Employer.RemoveAt(ind);
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.ToList();
                ConnectHelper.SaveListToFile(@"Input.txt");
            }
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                    x.YearAccesses >= 2016 && x.YearAccesses <= 2018).ToList();
                MessageBox.Show("2016-2018",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
                if (CmbFiltr.SelectedIndex == 1)
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                    x.YearAccesses >= 2018 && x.YearAccesses <= 2020).ToList();
                MessageBox.Show("2018-2020",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                   x.YearAccesses >= 2020).ToList();
                MessageBox.Show("2020>",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAddPreparate windowAdd = new WindowAddPreparate();
            windowAdd.ShowDialog();
        }
    }
}


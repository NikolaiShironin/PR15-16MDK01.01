﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ListClass.Classes;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // List<Pharmacy> pharmacies = new List<Pharmacy>();
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.Employer.Add(new Employees("Жуков.А.К", "Программист", 2021));
            ConnectHelper.Employer.Add(new Employees("Шляпов.А.К", "Программист", 2022));
            ConnectHelper.Employer.Add(new Employees("Жариков.А.К", "Программист", 2019));
            ConnectHelper.Employer.Add(new Employees("Жориков.А.К", "Сисадмин", 2019));
            ConnectHelper.Employer.Add(new Employees("Лукашев.А.К", "Пиар-Менеджер", 2018));
            ConnectHelper.Employer.Add(new Employees("Бублин.А.К", "Менеджер", 2022));
            ConnectHelper.Employer.Add(new Employees("Абобусов.А.К", "Уборщик", 2021));
            ConnectHelper.Employer.Add(new Employees("Лупович.А.К", "Маркетинг", 2022));

            DtgListWorkers.ItemsSource = ConnectHelper.Employer;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.ToList();
            DtgListWorkers.SelectedIndex = -1;
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.OrderBy(x => x.NameWorker).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.OrderByDescending(x => x.NameWorker).ToList();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x => x.NameWorker.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorkers.ItemsSource = null;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                    x.YearAccesses >= 2016 && x.YearAccesses <= 2018).ToList();
                MessageBox.Show("2016-2018",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
                if (CmbFiltr.SelectedIndex == 1)
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                    x.YearAccesses >= 2018 && x.YearAccesses <= 2020).ToList();
                MessageBox.Show("2018-2020",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                DtgListWorkers.ItemsSource = ConnectHelper.Employer.Where(x =>
                   x.YearAccesses >= 2020).ToList();
                MessageBox.Show("2020>",
                    "Дата Поступления", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAddPreparate windowAdd = new WindowAddPreparate();
            windowAdd.ShowDialog();
        }
    }
}


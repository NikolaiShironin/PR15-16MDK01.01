﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ListClass.Classes;

namespace ListClass
{
    /// <summary>
    /// Логика взаимодействия для WindowAddPreparate.xaml
    /// </summary>
    public partial class WindowAddPreparate : Window
    {
        int mode;
        public WindowAddPreparate()
        {
            InitializeComponent();
            mode = 0;
        }
        internal WindowAddPreparate(Employees pharm)
        {
            InitializeComponent();
            TxbName.Text = pharm.NameWorker;
            TxbPost.Text = pharm.PostWorker;
            TxbYear.Text = pharm.YearAccesses.ToString();
        }

        private void BtnAddWorker_Click(object sender, RoutedEventArgs e)
        {
            if (mode == 0)
            {
                try
                {
                    Employees employees = new Employees()
                    {
                        NameWorker = TxbName.Text,
                        PostWorker = TxbPost.Text,
                        YearAccesses = int.Parse(TxbYear.Text)
                    };
                    ConnectHelper.Employer.Add(employees);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Bruh");
                }
            }
            else
            {
                for (int i = 0; i < ConnectHelper.Employer.Count; i++)
                {
                    if (ConnectHelper.Employer[i].NameWorker == TxbName.Text)
                    {
                        ConnectHelper.Employer[i].PostWorker = TxbName.Text;
                        ConnectHelper.Employer[i].YearAccesses = int.Parse(TxbName.Text);
                    }
                }
            }
            ConnectHelper.SaveListToFile(@"Input.txt");
            this.Close();
        }
    }
}

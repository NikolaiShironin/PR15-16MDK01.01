﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListClass.Classes
{
    class ConnectHelper
    {
        public static List<Employees> Employer = new List<Employees>();
    }
}

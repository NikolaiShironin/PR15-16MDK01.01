﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ListClass.Classes
{
    class ConnectHelper
    {
        public static List<Employees> Employer = new List<Employees>();

        public static void ReadListFromFile(string filename)
        {
            StreamReader streamReader = new StreamReader(@"Input.txt", Encoding.UTF8);
            while (!streamReader.EndOfStream)
            {
                string line = streamReader.ReadLine();
                string[] items = line.Split(';');
                Employees pharmacy = new Employees()
                {
                    NameWorker = items[0],
                    PostWorker = items[1].Trim(),
                    YearAccesses = int.Parse(items[2].Trim())
                };
                Employer.Add(pharmacy);
            }
        }
        public static void SaveListToFile(string filename)
        {
            StreamWriter streamWriter = new StreamWriter(filename, false, Encoding.UTF8);
            foreach (Employees em in Employer)
            {
                streamWriter.WriteLine($"{em.NameWorker};{em.PostWorker};{em.YearAccesses};");
            }
            streamWriter.Close();
        }
    }
}
